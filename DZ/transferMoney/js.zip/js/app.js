function calculateCommission(amount,rate) {
    const percent = 0.002;
    const commission = (amount * rate) * percent;
    const minComission = 250;
    const maxComission = 450;
    if (commission < minComission){
        return minComission;
    }if (commission > maxComission) {
        return maxComission;
    }
    return commission;
}

const amount = 1000;
const rate = 11.40;

const result = calculateCommission(amount,rate);
console.log(result);
const post = {
  id: 'CN9_JAaBk-9',
  authorName: 'alifbank.tj',
  likes: 315,
  comments: 30,
  published: 1619095140
};
console.log(post);
'use strict';
function extractOwnerId(postId) {
  const ownerId = document.querySelector('[data-id="'+ postId + '"]');



  const res = ownerId.dataset.ownerid;
  return res;

}

//const postId = 24234;

extractOwnerId(24234);


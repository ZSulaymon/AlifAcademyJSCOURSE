'use strict';

setTimeout(() => {
  const loaderEl=document.querySelector('[data-id="loader"]');

  loaderEl.style.display = 'none';
},5000);

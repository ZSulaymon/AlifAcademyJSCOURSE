'use strict';

const rootEl = document.getElementById('root');
rootEl.innerHTML = `
    <h1>WishList</h1>
    <div data-id="loader">Загружаем данные...</div>
    <form data-id="wish-form">
        <fieldset data-id="wish-fieldset">
            <div data-id="message"></div>
            <div>
                <label for="name-input">Название</label>
                <input data-input="name" id="name-input">
            </div>
            <div>
                <label for="price-input">Цена</label>
                <input data-input="price" id="price-input" type="number">
            </div>
            <div>
                <label for="description-input">Описание</label>
                <textarea data-input="description" id="description-input" rows="5"></textarea>
            </div>
            <button>Добавить</button>
        </fieldset>
    </form>
    <div>Необходимо: <span data-id="total">0</span> с.</div>
    <ul data-id="wish-list"></ul>
`;

const loaderEl = rootEl.querySelector('[data-id="loader"]');
const wishesEl = rootEl.querySelector('[data-id="wish-list"]');

const apiUrl = 'http://127.0.0.1:9999/api/wishes';

const state = {
    wishes: [],
};

function loadData(callbacks) {
    if (typeof callbacks.onStart === 'function') {
        callbacks.onStart();
    }

    const xhr = new XMLHttpRequest();
    xhr.open('GET', apiUrl);
    xhr.onload = () => {
        if (xhr.status < 200 || xhr.status > 299) {
            const error = JSON.parse(xhr.responseText);
            if (typeof callbacks.onError === 'function') {
                callbacks.onError(error);
            }
            return;
        }

        const data = JSON.parse(xhr.responseText);
        if (typeof callbacks.onSuccess === 'function') {
            callbacks.onSuccess(data);
        }
    };
    xhr.onerror = () => {
        if (typeof callbacks.onError === 'function') {
            callbacks.onError({ error: 'network error' });
        }
    };
    xhr.onloadend = () => {
        if (typeof callbacks.onFinish === 'function') {
            callbacks.onFinish();
        }
    };
    xhr.send();
}

function renderWishes(wishesEl, wishes) {
    wishesEl.innerHTML = wishes.map(o => `
        <li>
            <div>Название: ${o.name}, цена: ${o.price} с. <button data-itemid="${o.id}" data-action="remove">Удалить</button></div>
            <div data-block="description">${o.description}</div>
        </li>
    `).join('');
}

loadData({
    onStart: () => loaderEl.style.display = 'block',
    onFinish: () => loaderEl.style.display = 'none',
    onSuccess: data => {
        state.wishes = data;
        renderWishes(wishesEl, state.wishes);
    },
    onError: error => console.log(error),
});

function removeDataById(id, callbacks) {
    if (typeof callbacks.onStart === 'function') {
        callbacks.onStart();
    }

    const xhr = new XMLHttpRequest();
    xhr.open('DELETE', `${apiUrl}/${id}`);
    xhr.onload = () => {
        if (xhr.status < 200 || xhr.status > 299) {
            const error = JSON.parse(xhr.responseText);
            if (typeof callbacks.onError === 'function') {
                callbacks.onError(error);
            }
            return;
        }

        if (typeof callbacks.onSuccess === 'function') {
            callbacks.onSuccess();
        }
    };
    xhr.onerror = () => {
        if (typeof callbacks.onError === 'function') {
            callbacks.onError({ error: 'network error' });
        }
    };
    xhr.onloadend = () => {
        if (typeof callbacks.onFinish === 'function') {
            callbacks.onFinish();
        }
    };
    xhr.send();
}

wishesEl.addEventListener('click', evt => {
    if (evt.target.dataset.action !== 'remove') {
        return;
    }

    const id = Number(evt.target.dataset.itemid);

    removeDataById(id, {
        onStart: () => loaderEl.style.display = 'block',
        onFinish: () => loaderEl.style.display = 'none',
        onSuccess: () => {
            state.wishes = state.wishes.filter(o => o.id !== id);
            renderWishes(wishesEl, state.wishes);
        },
        onError: error => console.log(error),
    })
});

function saveData(item, callbacks) {
    if (typeof callbacks.onStart === 'function') {
        callbacks.onStart();
    }

    const xhr = new XMLHttpRequest();
    xhr.open('POST', apiUrl);
    xhr.onload = () => {
        if (xhr.status < 200 || xhr.status > 299) {
            const error = JSON.parse(xhr.responseText);
            if (typeof callbacks.onError === 'function') {
                callbacks.onError(error);
            }
            return;
        }

        const data = JSON.parse(xhr.responseText);
        if (typeof callbacks.onSuccess === 'function') {
            callbacks.onSuccess(data);
        }
    };
    xhr.onerror = () => {
        if (typeof callbacks.onError === 'function') {
            callbacks.onError({ error: 'network error' });
        }
    };
    xhr.onloadend = () => {
        if (typeof callbacks.onFinish === 'function') {
            callbacks.onFinish();
        }
    };
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(item));
}

const formEl = rootEl.querySelector('[data-id="wish-form"]');
const fieldsetEl = formEl.querySelector('[data-id="wish-fieldset"]');
const nameEl = formEl.querySelector('[data-input="name"]');
const priceEl = formEl.querySelector('[data-input="price"]');
const descriptionEl = formEl.querySelector('[data-input="description"]');
formEl.onsubmit = evt => {
    evt.preventDefault();

    const id = 0;
    const name = nameEl.value.trim();
    const price = Number(priceEl.value);
    const description = descriptionEl.value.trim();
    // TODO: проверки из прошлой лекции
    const wish = {
        id,
        name,
        price,
        description,
    };

    saveData(wish, {
        onStart: () => {
            loaderEl.style.display = 'block';
            fieldsetEl.disabled = true;
        },
        onFinish: () => {
            loaderEl.style.display = 'none';
            fieldsetEl.disabled = false;
        },
        onSuccess: data => {
            state.wishes.unshift(data);
            renderWishes(wishesEl, state.wishes);
            formEl.reset();
        },
        onError: error => console.log(error),
    });
};
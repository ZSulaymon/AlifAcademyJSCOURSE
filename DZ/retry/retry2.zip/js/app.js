'use strict';

const rootEl = document.getElementById('root');

/*1-Media Wall
rootEl.innerHTML = `
    <div data-id="loader">Загружаем данные...</div>
    <div data-id="wall"></div>
`;

const loaderEl = rootEl.querySelector('[data-id="loader"]');
const wallEl = rootEl.querySelector('[data-id="wall"]');

const apiUrl = 'http://127.0.0.1:9999/api/hw29/posts';

const state = {
    posts: [],
};

function loadData(callbacks) {
    if (typeof callbacks.onStart === 'function') {
        callbacks.onStart();
    }

    const xhr = new XMLHttpRequest();
    xhr.open('GET', apiUrl);
    xhr.onload = () => {
        if (xhr.status < 200 || xhr.status > 299) {
            const error = JSON.parse(xhr.responseText);
            if (typeof callbacks.onError === 'function') {
                callbacks.onError(error);
            }
            return;
        }

        const data = JSON.parse(xhr.responseText);
        if (typeof callbacks.onSuccess === 'function') {
            callbacks.onSuccess(data);
        }
    };
    xhr.onerror = () => {
        if (typeof callbacks.onError === 'function') {
            callbacks.onError({error: 'network error'});
        }
    };
    xhr.onloadend = () => {
        if (typeof callbacks.onFinish === 'function') {
            callbacks.onFinish();
        }
    };
    xhr.send();
}

function renderPosts(postsEl, posts) {
    postsEl.innerHTML = posts
        .map((o) => {
            let innerBlock;
            switch (o.type) {
                case 'text':
                    innerBlock = `<div>${o.content}</div>`;
                    break;
                case 'image':
                    innerBlock = `<img src="${o.content}">`;
                    break;
                case 'video':
                    innerBlock = `<video src="${o.content}" controls>`;
                    break;
            }

            return `<div data-type="${o.type}" data-id="${o.id}">${innerBlock}</div>`;
        })
        .join('');
}

loadData({
    onStart: () => (loaderEl.style.display = 'block'),
    onFinish: () => rootEl.removeChild(loaderEl),
    onSuccess: (data) => {
        state.posts = data;
        renderPosts(wallEl, state.posts);
    },
    onError: (error) => console.log(error),
});
*/

rootEl.innerHTML = `
    <div data-id="buttons"><button data-action="load">Загрузить данные</button></div>
    <div data-id="wall"></div>
`;

const butonsEl = rootEl.querySelector('[data-id="buttons"]');
const wallEl = rootEl.querySelector('[data-id="wall"]');

const apiUrl = 'http://127.0.0.1:9999/api/hw30/posts';

let posts = [];

function loadData(callbacks) {
    if (typeof callbacks.onStart === 'function') {
        callbacks.onStart();
    }

    const xhr = new XMLHttpRequest();
    xhr.open('GET', apiUrl);
    xhr.onload = () => {
        if (xhr.status < 200 || xhr.status > 299) {
            const error = JSON.parse(xhr.responseText);
            if (typeof callbacks.onError === 'function') {
                callbacks.onError(error);
            }
            return;
        }

        const data = JSON.parse(xhr.responseText);
        if (typeof callbacks.onSuccess === 'function') {
            callbacks.onSuccess(data);
        }
    };
    xhr.onerror = () => {
        if (typeof callbacks.onError === 'function') {
            callbacks.onError({error: 'network error'});
        }
    };
    xhr.onloadend = () => {
        if (typeof callbacks.onFinish === 'function') {
            callbacks.onFinish();
        }
    };
    xhr.send();
}

function renderPosts(postsEl, elements) {
    postsEl.innerHTML = elements
        .map((o) => {
            let innerBlock;
            switch (o.type) {
                case 'text':
                    innerBlock = `<div>${o.content}</div>`;
                    break;
                case 'image':
                    innerBlock = `<img src="${o.content}">`;
                    break;
                case 'video':
                    innerBlock = `<video src="${o.content}" controls>`;
                    break;
            }

            return `<div data-type="${o.type}" data-id="${o.id}">${innerBlock}</div>`;
        })
        .join('');
}

butonsEl.addEventListener('click', (evt) => {
    wallEl.innerHTML = '';
    const loaderEl = makeLoaderEl();

    if (evt.target.dataset.action === 'load') {
        loadData({
            onStart: () =>
                rootEl.insertBefore(loaderEl, rootEl.firstElementChild),
            onFinish: () => loaderEl.remove(),
            onSuccess: (data) => {
                posts = data;
                renderPosts(wallEl, posts);
            },
            onError: (error) => {
                loaderEl.remove();
                butonsEl.innerHTML = `<div>
                    Произошла ошибка. <span data-id="error">${error.message}</span>
                    <button data-action="retry">Повторить запрос</button>
                </div>`;
            },
        });
        return;
    }

    butonsEl.innerHTML = '<button data-action="load">Загрузить данные</button>';

    loadData({
        onStart: () => rootEl.insertBefore(loaderEl, rootEl.firstElementChild),
        onSuccess: (data) => {
            posts = data;
            renderPosts(wallEl, posts);
        },
        onError: () => {
            loaderEl.remove();
        },
        onFinish: () => loaderEl.remove(),
    });
});

function makeLoaderEl() {
    const loaderEl = document.createElement('div');
    loaderEl.dataset.id = 'loader';
    loaderEl.textContent = 'Загружаем данные...';

    return loaderEl;
}

/*3-Library
function ajax(method, url, headers, callbacks, body) {
    const xhr = new XMLHttpRequest();
    xhr.open(method, url);

    if (typeof callbacks.onStart === 'function') {
        xhr.loadstart = callbacks.onStart();
    }

    if (typeof callbacks.onError === 'function' && typeof callbacks.onSuccess === 'function') {
        xhr.onload = (data) => {
            if (xhr.status < 200 || xhr.status > 299) {
                callbacks.onError(data);
                return;
            }
    
            callbacks.onSuccess(data.responseText);
        };
    }

    if (typeof callbacks.onFinish === 'function') {
        xhr.loadend = callbacks.onFinish();
    }

    if (typeof callbacks.onError === 'function') {
        xhr.onerror = callbacks.onError;
    }
    
    xhr.send(body);
}


ajax('GET', 'http://127.0.0.1:9999/api/hw31/success', {}, {
    onStart: () => {console.log('onStart')},
    onFinish: () => {console.log('onFinish')},
    onError: error => {console.log('onError', error)},
    onSuccess: data => {console.log('onSuccess', data)},
}, null);
*/
